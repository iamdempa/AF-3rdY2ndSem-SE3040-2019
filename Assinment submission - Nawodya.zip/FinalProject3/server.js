const express = require('express');
const fileUpload=require('express-fileupload');

const app = express();


app.use(fileUpload());
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

//upload endpoiint

app.post('/upload',(req,res)=>{
    console.log(req);
    console.log(req.files);
    if(req.files===null){
        console.log("here1");
        return res.status(400).json({msg:'no file uploaded'});
    }

    

    const file=req.files.file;

    file.mv(`${__dirname}/client/public/uploads/${file.name}`,err=>{
        if(err){
            console.error(err);
            return res.status(500).send(err);
        }
        res.json({fileName: file.name,filePath:'/uploads/${file.name}'});
        });
});

app.listen(5000,()=>console.log('server started..'));